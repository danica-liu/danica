import pandas as pd
import  os

# 修改为自己的地址与文件名
path = 'D:/scrapt/WeiboSuperSpider-master/无 GUI 功能独立版/topic/'
csvPath = path + 'POLA.csv'
if not os.path.exists(csvPath):
    print('Not that xfiles:%s' % csvPath)


txtPath = path + 'POLA.txt'
data = pd.read_csv(csvPath, encoding='utf-8')

with open(txtPath, 'a+', encoding='utf-8') as f:
    for line in data.values:
        f.write((str(line[6]) + '\n'))