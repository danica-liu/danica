import csv
import re

import jieba
import numpy as np
import requests
import lxml.etree as etree
import matplotlib.pyplot as plt
from wordcloud import WordCloud


if __name__ == '__main__':
    #分析爬取数据，绘制词云
    #改成自己的txt文件地址
    text_from_file_with_apath = open(r'xxxx.txt',encoding='utf-8').read()
    wordlist_after_jieba = jieba.cut(text_from_file_with_apath, cut_all=True)
    wl_space_split = " ".join(wordlist_after_jieba)
    cloud = WordCloud(
        font_path="simkai.ttf",
        width=800,
        height=400,
        background_color='white',
        max_words=9000
    )  # .generate(wl_space_split)

    ## 产生词云
    word_cloud = cloud.generate(wl_space_split)
    # 将图片保存到指定地址中
    word_cloud.to_file('xxxx')
